
// function openCity(evt, cityName) {
//   var i, tabcontent, tablinks;
//   tabcontent = document.getElementsByClassName("tabcontent");
//   for (i = 0; i < tabcontent.length; i++) {
//     tabcontent[i].style.display = "none";
//   }
//   tablinks = document.getElementsByClassName("tablinks");
//   for (i = 0; i < tablinks.length; i++) {
//     tablinks[i].className = tablinks[i].className.replace(" active", "");
//   }
//   document.getElementById(cityName).style.display = "block";
//   evt.currentTarget.className += " active";
// }

// // Get the element with id="defaultOpen" and click on it
// document.getElementById("defaultOpen").click();

   
$(document).ready(function() {
    $('.panel-collapse').on('show.bs.collapse', function () {
      $(this).siblings('.panel-heading').addClass('active');
    });
  
    $('.panel-collapse').on('hide.bs.collapse', function () {
      $(this).siblings('.panel-heading').removeClass('active');
    });
  });
  


//   $(document).ready(function () {
//     $('input[type=button]').click(function () {
//          $('#target').toggleClass('active-bg');
//     });
// });

$(".value-div .btn").click(function () {
  $(this).closest('.tab-header-content').toggleClass('tab-header-activated');
  $(this).toggleClass('active-btn');
  $(this).find('i.material-icons').text('keyboard_arrow_down');
  if ($(this).hasClass('active-btn'))
    $(this).find('i.material-icons').text('keyboard_arrow_up');
});

$(".panel-heading").each(function(elem) {
  if ($(this).hasClass('active')) {
    $(this).find("i.material-icons").text('keyboard_arrow_up');
  }
})


$(".panel-heading .panel-title a").click(function (e) {
  e.preventDefault();
  $('.panel-heading').find('i.material-icons').text('keyboard_arrow_down');
  if (!$(this).closest('.panel-heading').hasClass('active')) {
    $(this).find('i.material-icons').text('keyboard_arrow_up');
  }
})

$(".progress-container button").click(function(e) {
  e.preventDefault();
  setTimeout(function() {
    $(this).html('Less Fund<i class="large material-icons">keyboard_arrow_up</i>');
    if ($(this).hasClass('collapsed')) {
      $(this).html('View Fund<i class="large material-icons">keyboard_arrow_down</i>');
    }
  }, 1000);
  
})
$('.collapse').on('show.bs.collapse', function (e) {
  $(this).siblings().find('button').html('Less Fund<i class="large material-icons">keyboard_arrow_up</i>');
}).on('hidden.bs.collapse', function (e) {
  $(this).siblings().find('button').html('View Fund<i class="large material-icons">keyboard_arrow_down</i>');
});;