import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { PortfolioModule } from './portfolio/portfolio.module';
// import { PortfolioComponent } from './portfolio/portfolio.component';
// import { MyholdingsComponent } from './portfolio/myholdings/myholdings.component';
// import { AssetallocationComponent } from './portfolio/assetallocation/assetallocation.component';
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
   
    
    
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    PortfolioModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
