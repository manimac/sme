import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assetallocation',
  templateUrl: './assetallocation.component.html',
  styleUrls: ['./assetallocation.component.css']
})
export class AssetallocationComponent implements OnInit {

  isCollapsedone: boolean = false;
  constructor() { }

  ngOnInit() {
  }
 
 
}
