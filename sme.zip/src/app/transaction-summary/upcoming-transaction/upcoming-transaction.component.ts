import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upcoming-transaction',
  templateUrl: './upcoming-transaction.component.html',
  styleUrls: ['./upcoming-transaction.component.css']
})
export class UpcomingTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
