import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-transaction',
  templateUrl: './latest-transaction.component.html',
  styleUrls: ['./latest-transaction.component.css']
})
export class LatestTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
