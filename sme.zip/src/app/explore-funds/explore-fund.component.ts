import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-explore-fund',
  templateUrl: './explore-fund.component.html',
  styleUrls: ['./explore-fund.component.css']
})
export class ExploreFundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
