import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swp',
  templateUrl: './swp.component.html',
  styleUrls: ['./swp.component.css']
})
export class SwpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
