import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-folio-link-delink',
  templateUrl: './folio-link-delink.component.html',
  styleUrls: ['./folio-link-delink.component.css']
})
export class FolioLinkDelinkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
