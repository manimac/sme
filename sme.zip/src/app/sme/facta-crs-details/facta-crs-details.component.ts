import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facta-crs-details',
  templateUrl: './facta-crs-details.component.html',
  styleUrls: ['./facta-crs-details.component.css']
})
export class FactaCrsDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
