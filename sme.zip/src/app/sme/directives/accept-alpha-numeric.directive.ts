import { Directive } from '@angular/core';

@Directive({
  selector: '[appAcceptAlphaNumeric]'
})
export class AcceptAlphaNumericDirective {

  constructor() { }

}
