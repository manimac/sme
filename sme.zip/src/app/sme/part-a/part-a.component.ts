import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-part-a',
  templateUrl: './part-a.component.html',
  styleUrls: ['./part-a.component.css']
})
export class PartAComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
