import { FilterArrayPipe } from './filter-array.pipe';

describe('FilterArrayPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterArrayPipe();
    expect(pipe).toBeTruthy();
  });
});
