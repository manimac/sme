import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-city-country',
  templateUrl: './city-country.component.html',
  styleUrls: ['./city-country.component.css']
})
export class CityCountryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
