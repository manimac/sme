import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ultimate-beneficiary-owner',
  templateUrl: './ultimate-beneficiary-owner.component.html',
  styleUrls: ['./ultimate-beneficiary-owner.component.css']
})
export class UltimateBeneficiaryOwnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
